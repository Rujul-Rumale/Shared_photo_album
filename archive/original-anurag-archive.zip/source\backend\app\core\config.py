"""
Core configuration for Anurag University Memories.
Uses Pydantic Settings for environment-based configuration.
"""

from pydantic_settings import BaseSettings
from functools import lru_cache
from typing import Optional
import secrets

class Settings(BaseSettings):
    # ─── Application ─────────────────────────────────────────────────
    APP_NAME: str = "Anurag University Memories"
    APP_VERSION: str = "1.0.0"
    DEBUG: bool = False
    ENVIRONMENT: str = "production"  # development, staging, production

    # ─── Database ────────────────────────────────────────────────────
    DATABASE_URL: str = "postgresql://postgres:postgres@db:5432/anurag_memories"
    # Fallback to SQLite for local dev without Docker
    SQLITE_PATH: str = "./anurag_memories.db"

    # ─── Security ────────────────────────────────────────────────────
    SECRET_KEY: str = secrets.token_urlsafe(32)
    JWT_ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 10080  # 7 days
    REFRESH_TOKEN_EXPIRE_DAYS: int = 30

    # ─── Google OAuth ────────────────────────────────────────────────
    GOOGLE_CLIENT_ID: str = ""
    GOOGLE_CLIENT_SECRET: str = ""
    GOOGLE_REDIRECT_URI: str = "http://localhost:8000/api/v1/auth/callback"

    # ─── CORS ────────────────────────────────────────────────────────
    CORS_ORIGINS: str = "http://localhost:3000,http://localhost:5173"

    # ─── Storage (Raspberry Pi + Tailscale) ──────────────────────────
    STORAGE_BACKEND: str = "raspberry_pi"  # or "local", "s3"
    STORAGE_BASE_PATH: str = "/mnt/storage/anurag-memories"
    RASPBERRY_PI_HOST: str = "raspberry-pi.tailnet"
    RASPBERRY_PI_SSH_KEY: Optional[str] = None
    TAILSCALE_AUTH_KEY: Optional[str] = None

    # ─── Upload Limits ───────────────────────────────────────────────
    MAX_UPLOAD_SIZE_MB: int = 500  # 500MB for videos
    CHUNK_SIZE_BYTES: int = 5 * 1024 * 1024  # 5MB chunks for resumable uploads
    ALLOWED_IMAGE_TYPES: str = "image/jpeg,image/png,image/heic,image/webp"
    ALLOWED_VIDEO_TYPES: str = "video/mp4,video/quicktime,video/x-msvideo"

    # ─── Time Capsule ────────────────────────────────────────────────
    GRADUATION_DATE: str = "2026-05-15"  # When capsule unlocks
    CAPSULE_SEAL_DEADLINE: Optional[str] = "2026-05-01"

    # ─── Email (for graduation migration notice) ─────────────────────
    SMTP_HOST: Optional[str] = None
    SMTP_PORT: int = 587
    SMTP_USER: Optional[str] = None
    SMTP_PASSWORD: Optional[str] = None
    EMAIL_FROM: str = "archive@anurag.edu.in"

    # ─── Admin ───────────────────────────────────────────────────────
    ADMIN_EMAILS: str = ""  # Comma-separated list of admin emails

    @property
    def cors_origins_list(self) -> list[str]:
        return [origin.strip() for origin in self.CORS_ORIGINS.split(",")]

    @property
    def allowed_mime_types(self) -> list[str]:
        images = self.ALLOWED_IMAGE_TYPES.split(",")
        videos = self.ALLOWED_VIDEO_TYPES.split(",")
        return images + videos

    @property
    def admin_emails_list(self) -> list[str]:
        if not self.ADMIN_EMAILS:
            return []
        return [email.strip().lower() for email in self.ADMIN_EMAILS.split(",")]

    class Config:
        env_file = ".env"
        case_sensitive = True

@lru_cache()
def get_settings() -> Settings:
    return Settings()
