import { type ClassValue, clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatFileSize(bytes: number): string {
  if (bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

export function formatDate(dateString: string): string {
  const date = new Date(dateString);
  return date.toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });
}

export function getDaysUntil(dateString: string): number {
  const target = new Date(dateString);
  const now = new Date();
  const diff = target.getTime() - now.getTime();
  return Math.max(0, Math.ceil(diff / (1000 * 60 * 60 * 24)));
}

export function getRandomTilt(): string {
  const tilts = ['-rotate-2', 'rotate-2', '-rotate-1', 'rotate-1', '-rotate-3', 'rotate-3'];
  return tilts[Math.floor(Math.random() * tilts.length)];
}

export const ALBUM_TILTS: Record<string, string> = {
  freshers: '-rotate-2',
  'college-life': 'rotate-2',
  hackathons: '-rotate-1',
  competitions: 'rotate-1',
  clubs: '-rotate-2',
  trips: 'rotate-2',
  hostel: '-rotate-1',
  labs: 'rotate-1',
  farewell: '-rotate-2',
  misc: 'rotate-2',
};
