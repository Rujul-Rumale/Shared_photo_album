# Anurag University Memories -- Product Vision

## Vision

Build a long-lived digital archive for one graduating batch. The product
is **not** a social network. It is a curated, nostalgic archive that
preserves college memories for decades.

### Core Principles

-   Photos and videos are reviewed before publication.
-   Every contributor is identified by their college Google account.
-   No likes, comments, reels, feeds, followers, or algorithms.
-   The archive belongs to the batch, not a single event.
-   Mobile-first upload experience.

## Core Features

-   Albums (Freshers, College Life, Hackathons, Competitions, Clubs,
    Trips, Hostel, Labs, Farewell, Misc.)
-   Public/shared curated galleries.
-   Upload queue with moderation.
-   Time Capsule.
-   Google Sign-In using `@anurag.edu.in`.
-   One-time invite code for first registration.
-   One day before graduation, email users to link a personal Google
    account while preserving identity.
-   External HDD attached to Raspberry Pi stores originals.
-   Oracle Always Free hosts frontend/API.

## Time Capsule

A special sealed collection that accepts: - Photos - Videos - Messages

Rules: - No anonymous submissions. - Every message is permanently
attributed to its author. - Editable until the capsule is sealed. -
Opens only on Graduation Day.

Suggested prompts: - Message to the class - Letter to your future self -
Where do you see yourself in 5 years?

When opened, present a ceremonial reveal before showing content.
