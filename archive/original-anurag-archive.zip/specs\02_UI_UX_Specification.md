# UI / UX Specification

## Style

Minimal, timeless, warm. Inspired by Apple, Notion, VSCO.

## Navigation

-   Home
-   Albums
-   Time Capsule
-   About
-   Contribute
-   Profile

## Home

Hero banner with mission statement. Album cards. Statistics. Footer.

## Album Card

Cover image Title Description Photo/video counts Contribute button

If empty: 'No memories published yet. Your uploads will be reviewed,
curated and compiled into the shared album.'

## Upload Flow

1.  Choose album
2.  Drag/drop or browse
3.  Preview grid
4.  Remove unwanted items
5.  Optional note
6.  Upload with progress
7.  Success screen

Success notice: If you accidentally uploaded something you do not want
shared with the class, contact us via WhatsApp or email before
publication.

## Gallery

Pinterest-style masonry. Fullscreen viewer. Metadata: - Contributor -
Date - Album

## Admin

Dashboard Pending uploads Approve / Reject / Move Album management
Invite codes Users Storage health

## Time Capsule

Dark themed. Countdown. Contribution button. Sealed state. Opening
ceremony animation. Messages displayed as signed letters.
