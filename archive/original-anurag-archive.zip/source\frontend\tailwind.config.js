/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        'au-bg': '#1f1c1a',
        'au-bg-dark': '#171413',
        'au-card': '#282320',
        'au-card-hover': '#342d29',
        'au-accent': '#b87352',
        'au-accent-hover': '#a06042',
        'au-gold': '#c5a059',
        'au-text': '#f8f5f0',
        'au-text-muted': '#b0a294',
        'au-text-dim': '#8c7f72',
        'au-polaroid': '#f8f5f0',
        'au-polaroid-text': '#2b2623',
        'au-border': 'rgba(248, 245, 240, 0.09)',
        'au-sage': '#8a9a86',
      },
      fontFamily: {
        'serif-title': ['Fraunces', 'Georgia', 'serif'],
        'handwriting': ['Kalam', 'cursive'],
        'scribble': ['Caveat', 'cursive'],
        'sans': ['Plus Jakarta Sans', 'system-ui', 'sans-serif'],
      },
      animation: {
        'fade-in': 'fadeIn 0.5s ease-out',
        'slide-up': 'slideUp 0.4s ease-out',
        'polaroid-tilt': 'polaroidTilt 0.3s ease-out',
      },
      keyframes: {
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        slideUp: {
          '0%': { opacity: '0', transform: 'translateY(20px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        polaroidTilt: {
          '0%': { transform: 'rotate(0deg) scale(1)' },
          '100%': { transform: 'rotate(var(--tw-rotate)) scale(1.02)' },
        },
      },
    },
  },
  plugins: [],
}