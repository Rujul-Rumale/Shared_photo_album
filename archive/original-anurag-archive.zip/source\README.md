# Anurag University Memories

> A curated digital scrapbook for the graduating class of 2022–2026.
> No algorithms. No likes. Just memories, preserved for decades.

## Architecture

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│   React + TS    │────▶│   FastAPI       │────▶│   PostgreSQL    │
│   Tailwind CSS  │     │   (Oracle Free) │     │   (Docker)      │
└─────────────────┘     └─────────────────┘     └─────────────────┘
        │                        │
        │                        ▼
        │               ┌─────────────────┐
        │               │   Raspberry Pi  │
        │               │   + External    │
        │               │   HDD (Tailscale) │
        │               └─────────────────┘
        ▼
┌─────────────────┐
│   Caddy/Nginx   │
│   Reverse Proxy │
└─────────────────┘
```

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React 18, TypeScript, Tailwind CSS, Vite |
| State | Zustand, TanStack Query |
| Backend | FastAPI, Python 3.11 |
| Database | PostgreSQL 16 (SQLite for dev) |
| Auth | Google OAuth 2.0 + JWT |
| Storage | Raspberry Pi + External HDD over Tailscale |
| Hosting | Oracle Cloud Always Free (API), Docker Compose |
| Proxy | Caddy (production) / Nginx (development) |

## Quick Start

### Prerequisites
- Docker & Docker Compose
- Node.js 20+ (for local frontend dev)
- Python 3.11+ (for local backend dev)

### 1. Clone & Configure

```bash
git clone <repo>
cd anurag-university-memories
cp .env.example .env
# Edit .env with your Google OAuth credentials
```

### 2. Run with Docker Compose

```bash
docker-compose up --build
```

This starts:
- **Frontend** at http://localhost:80
- **API** at http://localhost:8000
- **PostgreSQL** at localhost:5432

### 3. Seed Data

```bash
docker-compose exec api python scripts/seed_data.py
```

### 4. Local Development (without Docker)

**Backend:**
```bash
cd backend
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python scripts/seed_data.py
uvicorn app.main:app --reload --port 8000
```

**Frontend:**
```bash
cd frontend
npm install
npm run dev
```

## Features

### Authentication
- Google Sign-In restricted to `@anurag.edu.in` accounts
- One-time invite code for first registration
- JWT tokens with 7-day expiry
- Personal email linking for post-graduation access
- Immutable UUID-based identity

### Albums (10 Curated Stacks)
1. Freshers Orientation
2. Campus Quad & Canteen
3. Hackathons & Late Nights
4. Sports & Cultural Fests
5. Clubs & Societies
6. Batch Trips & Treks
7. Hostel Chronicles
8. Labs & Submissions
9. Farewell & Traditional Day
10. Unfiltered Candid Moments

### Upload Flow
- Drag & drop with preview
- Multi-select support
- Progress tracking
- Resumable chunked uploads for large videos (up to 500MB)
- SHA-256 checksums for integrity
- Moderation queue before publication

### Time Capsule
- Sealed until Graduation Day (May 15, 2026)
- Signed messages with ink color selection
- No anonymous content
- Ceremonial reveal animation
- Editable until sealed

### Admin Dashboard
- Pending moderation queue
- Approve / Reject / Move
- Album management
- Invite code generation
- User management & promotion
- Storage health monitoring

## Database Schema

See `backend/app/models/base.py` for full SQLAlchemy models:
- `users` — Immutable UUID identity, role-based access
- `albums` — Curated photo stacks
- `media` — Photos/videos with moderation status
- `time_capsule_entries` — Sealed graduation messages
- `invite_codes` — One-time registration stamps
- `system_config` — Graduation date & settings

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/v1/auth/google` | Google OAuth login |
| GET | `/api/v1/auth/me` | Current user |
| GET | `/api/v1/albums` | List albums |
| GET | `/api/v1/albums/{slug}` | Album detail |
| POST | `/api/v1/media/upload` | Upload media |
| GET | `/api/v1/media` | List media |
| GET | `/api/v1/media/pending` | Pending moderation |
| POST | `/api/v1/media/{id}/moderate` | Approve/reject |
| GET | `/api/v1/capsule` | List entries |
| POST | `/api/v1/capsule` | Create entry |
| POST | `/api/v1/capsule/seal` | Seal capsule |
| GET | `/api/v1/admin/stats` | Dashboard stats |
| POST | `/api/v1/invites/generate` | Generate codes |

## Deployment

### Oracle Cloud Always Free (API)
1. Create an Ampere A1 instance (4 OCPU, 24GB RAM)
2. Install Docker: `curl -fsSL https://get.docker.com | sh`
3. Clone repo and run `docker-compose up -d`
4. Configure firewall rules for ports 80, 443, 8000

### Raspberry Pi Storage
1. Attach external HDD to Raspberry Pi
2. Install Tailscale: `curl -fsSL https://tailscale.com/install.sh | sh`
3. Join tailnet and authorize the API server
4. Mount HDD at `/mnt/storage/anurag-memories`
5. Configure `STORAGE_BACKEND=raspberry_pi` in `.env`

### Caddy (Production SSL)
```bash
cp Caddyfile /etc/caddy/Caddyfile
systemctl restart caddy
```

## Security

- All uploads moderated before publication
- Only `@anurag.edu.in` accounts can register
- Invite codes prevent unauthorized access
- HTTP-only cookies for session management
- CORS restricted to known origins
- SHA-256 checksums for file integrity
- Role-based access control (student, curator, admin)

## License

MIT License — Anurag University Batch Committee 2022–2026

> "Once an Anuragian, always an Anuragian."
