import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { Sparkles, ArrowRight, Upload, Camera, Lock } from 'lucide-react';
import { albumsApi } from '@/api';
import PolaroidCard from '@/components/PolaroidCard';
import type { Album } from '@/types';

const STATS = [
  { label: 'Photo Vaults', val: '10 Stacks' },
  { label: 'Archived Moments', val: '870+ Photos' },
  { label: 'Graduating Batch', val: 'Class of 2026' },
  { label: 'Lifetime Vault', val: 'Permanent' },
];

export default function HomePage() {
  const { data: albumsData } = useQuery({
    queryKey: ['albums'],
    queryFn: () => albumsApi.list(),
  });

  const albums: Album[] = albumsData?.data || [];

  return (
    <div className="space-y-16 pb-20">
      {/* Hero Section */}
      <section className="relative pt-12 sm:pt-16 pb-12 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          <div className="lg:col-span-7 space-y-6 text-center lg:text-left">
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-au-card border border-au-border text-au-gold text-xs font-handwriting text-base">
              <Sparkles className="w-4 h-4 text-au-gold" />
              <span>Official Class of 2022–2026 Digital Scrapbook</span>
            </div>

            <h1 className="text-3xl sm:text-5xl lg:text-6xl font-normal text-white leading-[1.15] font-serif-title">
              Preserving our best college days, <br />
              <span className="italic text-au-gold">one memory at a time.</span>
            </h1>

            <p className="text-[#c7bbb0] text-xs sm:text-sm lg:text-base max-w-2xl leading-relaxed">
              No algorithms, no likes, no feeds. Just authentic and warm photographs of Anurag University saved permanently for our batch reunion decades from now.
            </p>

            <div className="pt-2 flex flex-wrap items-center justify-center lg:justify-start gap-4">
              <Link
                to="/albums"
                className="bg-au-accent hover:bg-au-accent-hover text-white px-7 py-3.5 rounded-2xl text-xs sm:text-sm font-bold transition shadow-xl shadow-amber-950/30 flex items-center gap-2"
              >
                <span>Browse Memory Vaults</span>
                <ArrowRight className="w-4 h-4" />
              </Link>

              <Link
                to="/contribute"
                className="bg-au-card hover:bg-au-card-hover text-au-text px-7 py-3.5 rounded-2xl text-xs sm:text-sm font-semibold border border-au-border transition flex items-center gap-2"
              >
                <Upload className="w-4 h-4 text-au-gold" />
                <span>Upload a Photograph</span>
              </Link>
            </div>

            {/* Stats */}
            <div className="pt-6 grid grid-cols-2 sm:grid-cols-4 gap-4">
              {STATS.map((stat, idx) => (
                <div key={idx} className="bg-au-card/90 border border-au-border p-3.5 rounded-2xl text-center">
                  <div className="text-base sm:text-lg font-bold text-au-gold font-serif-title">{stat.val}</div>
                  <div className="text-[11px] text-au-text-muted mt-0.5">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Polaroid Stack */}
          <div className="lg:col-span-5 relative flex justify-center py-6">
            <div className="relative w-72 sm:w-80">
              <div className="polaroid-card p-4 rounded-xl -rotate-6 transform translate-x-4 translate-y-2 absolute inset-0 opacity-80 pointer-events-none">
                <div className="aspect-[4/3] bg-zinc-800 rounded-lg overflow-hidden">
                  <img src="https://images.unsplash.com/photo-1511632765486-a01980e01a18?auto=format&fit=crop&w=600&q=80" alt="Freshers" className="w-full h-full object-cover" />
                </div>
                <div className="pt-3 text-center font-handwriting text-base text-[#3b332e]">Orientation Day 2022</div>
              </div>

              <div className="polaroid-card p-4 rounded-xl rotate-6 transform -translate-x-4 translate-y-4 relative z-10 shadow-2xl">
                <div className="aspect-[4/3] bg-zinc-800 rounded-lg overflow-hidden">
                  <img src="https://images.unsplash.com/photo-1541339907198-e08756dedf3f?auto=format&fit=crop&w=600&q=80" alt="Quad" className="w-full h-full object-cover" />
                </div>
                <div className="pt-3 text-center font-handwriting text-lg text-[#2b2623] font-bold">Canteen Staircase Squad ☕</div>
                <div className="tape-strip absolute -top-3 right-8 w-20 h-6 rounded-sm rotate-3" />
              </div>

              <div className="ticket-stub absolute -bottom-6 -left-6 z-20 px-3 py-2 rounded-lg text-xs font-handwriting -rotate-12 shadow-lg hidden sm:block">
                <span>🎫 AU Canteen • 1x Special Chai</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Albums */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 border-b border-au-border pb-5">
          <div>
            <span className="text-xs text-au-gold font-handwriting text-lg">Our Scrapbook Stacks</span>
            <h2 className="text-2xl sm:text-3xl font-normal text-white font-serif-title">Curated Memory Vaults</h2>
          </div>
          <Link to="/albums" className="text-xs font-semibold text-au-gold hover:underline flex items-center gap-1 self-start sm:self-auto">
            <span>Explore All 10 Vaults</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {albums.slice(0, 6).map((album) => (
            <PolaroidCard key={album.id} album={album} href={`/albums/${album.slug}`} />
          ))}
        </div>
      </section>

      {/* Time Capsule Banner */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-gradient-to-r from-au-card to-au-card-hover border border-au-border rounded-3xl p-8 sm:p-12 relative overflow-hidden shadow-2xl">
          <div className="max-w-2xl space-y-4 relative z-10">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-au-gold/10 text-au-gold text-xs font-handwriting text-base">
              <Lock className="w-3.5 h-3.5" />
              <span>Sealed Capsule • Opens Graduation Day</span>
            </div>

            <h2 className="text-2xl sm:text-4xl font-normal text-white font-serif-title">
              Leave a Letter for Graduation Day
            </h2>

            <p className="text-[#c7bbb0] text-xs sm:text-sm leading-relaxed">
              Write a signed personal letter to your future self or leave a farewell note for the batch. All entries are sealed safely until the ceremonial reveal on Graduation Day.
            </p>

            <div className="pt-2">
              <Link
                to="/timecapsule"
                className="bg-au-accent hover:bg-au-accent-hover text-white px-6 py-3 rounded-2xl text-xs font-bold transition shadow-lg shadow-amber-950/30 flex items-center gap-2 inline-flex"
              >
                <span>Write Time Capsule Letter</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
