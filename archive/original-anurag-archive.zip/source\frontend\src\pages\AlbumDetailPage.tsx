import { useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { Camera, Upload, ArrowLeft } from 'lucide-react';
import { albumsApi, mediaApi } from '@/api';
import MediaPolaroid from '@/components/MediaPolaroid';
import LightboxModal from '@/components/LightboxModal';
import type { Album, MediaItem } from '@/types';

export default function AlbumDetailPage() {
  const { slug } = useParams<{ slug: string }>();
  const [lightboxItem, setLightboxItem] = useState<MediaItem | null>(null);

  const { data: albumData } = useQuery({
    queryKey: ['album', slug],
    queryFn: () => albumsApi.getBySlug(slug!),
    enabled: !!slug,
  });

  const { data: mediaData } = useQuery({
    queryKey: ['media', slug],
    queryFn: () => mediaApi.list({ album_id: albumData?.data?.id }),
    enabled: !!albumData?.data?.id,
  });

  const album: Album | undefined = albumData?.data;
  const media: MediaItem[] = mediaData?.data?.items || [];

  if (!album) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 text-center">
        <Camera className="w-12 h-12 text-au-text-muted mx-auto mb-4" />
        <p className="text-au-text-muted">Loading album...</p>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-10">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-au-border pb-6">
        <div>
          <span className="text-xs text-au-gold font-handwriting text-lg">Curated Memory Vaults</span>
          <h1 className="text-2xl sm:text-4xl font-normal text-white font-serif-title">{album.name}</h1>
          <p className="text-xs text-[#c7bbb0] mt-1 max-w-xl">{album.description}</p>
        </div>
        <div className="flex gap-2">
          <Link
            to="/albums"
            className="bg-au-card hover:bg-au-card-hover text-au-text px-4 py-2 rounded-2xl text-xs font-semibold border border-au-border transition self-start"
          >
            <ArrowLeft className="w-4 h-4 inline mr-1" />
            Back to All Stacks
          </Link>
          <Link
            to="/contribute"
            className="bg-au-accent hover:bg-au-accent-hover text-white px-5 py-2.5 rounded-2xl text-xs font-bold transition shadow-lg shadow-amber-950/30 flex items-center gap-2 self-start"
          >
            <Upload className="w-4 h-4" />
            <span>Share a Memory</span>
          </Link>
        </div>
      </div>

      {media.length === 0 ? (
        <div className="bg-au-card border border-au-border p-12 rounded-3xl text-center space-y-4 max-w-xl mx-auto">
          <Camera className="w-12 h-12 text-au-text-muted mx-auto" />
          <h3 className="text-lg font-bold text-white font-serif-title">No Memories Published Yet</h3>
          <p className="text-xs text-au-text-muted leading-relaxed">
            No memories published yet in this stack. Your submitted uploads will be reviewed, curated, and added here.
          </p>
          <Link
            to="/contribute"
            className="bg-au-accent text-white px-5 py-2.5 rounded-2xl text-xs font-bold transition inline-block"
          >
            Upload First Photo
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {media.map((item) => (
            <MediaPolaroid
              key={item.id}
              item={item}
              onClick={() => setLightboxItem(item)}
            />
          ))}
        </div>
      )}

      {lightboxItem && (
        <LightboxModal
          item={lightboxItem}
          album={album}
          onClose={() => setLightboxItem(null)}
        />
      )}
    </div>
  );
}
