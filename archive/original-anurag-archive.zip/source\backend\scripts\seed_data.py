"""
Database seeding script for initial data.
Run once after database initialization.
"""

import logging
from sqlalchemy.orm import Session
from app.core.database import SessionLocal, engine
from app.models.base import Base, Album, SystemConfig

logger = logging.getLogger(__name__)

ALBUMS = [
    {
        "slug": "freshers",
        "name": "Freshers Orientation",
        "description": "Nervous welcomes in the main hall, making our very first AU friends, and wide-eyed campus tours.",
        "cover_url": "https://images.unsplash.com/photo-1523580494863-6f3031224c94?auto=format&fit=crop&w=800&q=80",
        "tag": "The Beginning",
        "sort_order": 1,
    },
    {
        "slug": "college-life",
        "name": "Campus Quad & Canteen",
        "description": "Hot samosas at the canteen, acoustic guitar sessions on the staircase, and golden hour campus walks.",
        "cover_url": "https://images.unsplash.com/photo-1541339907198-e08756dedf3f?auto=format&fit=crop&w=800&q=80",
        "tag": "Daily Life",
        "sort_order": 2,
    },
    {
        "slug": "hackathons",
        "name": "Hackathons & Late Nights",
        "description": "24-hour non-stop coding, extra strong chai, fixing bugs at 4 AM, and winning pitch presentations.",
        "cover_url": "https://images.unsplash.com/photo-1504384308090-c894fdcc538d?auto=format&fit=crop&w=800&q=80",
        "tag": "Late Nights",
        "sort_order": 3,
    },
    {
        "slug": "competitions",
        "name": "Sports & Cultural Fests",
        "description": "Loud cheering from the ground, inter-college dance face-offs, cricket finals, and trophies held high.",
        "cover_url": "https://images.unsplash.com/photo-1511578314322-379afb476865?auto=format&fit=crop&w=800&q=80",
        "tag": "Celebrations",
        "sort_order": 4,
    },
    {
        "slug": "clubs",
        "name": "Clubs & Societies",
        "description": "Rotaract, IEEE, Drama, and Coding workshops, weekend retreats, and brainstorming sessions.",
        "cover_url": "https://images.unsplash.com/photo-1529156069898-49953e39b3ac?auto=format&fit=crop&w=800&q=80",
        "tag": "Communities",
        "sort_order": 5,
    },
    {
        "slug": "trips",
        "name": "Batch Trips & Treks",
        "description": "Monsoon treks through Ananthagiri Hills, Araku Valley train journeys, and roadside dhaba dinners.",
        "cover_url": "https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?auto=format&fit=crop&w=800&q=80",
        "tag": "Getaways",
        "sort_order": 6,
    },
    {
        "slug": "hostel",
        "name": "Hostel Chronicles",
        "description": "Midnight birthday pranks, room-brewed Maggi, terrace singing sessions, and exam night prep.",
        "cover_url": "https://images.unsplash.com/photo-1555854877-bab0e564b8d5?auto=format&fit=crop&w=800&q=80",
        "tag": "Hostel Stories",
        "sort_order": 7,
    },
    {
        "slug": "labs",
        "name": "Labs & Submissions",
        "description": "VLSI lab stress, record notebook signature chases, viva voce laughs, and project setups.",
        "cover_url": "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?auto=format&fit=crop&w=800&q=80",
        "tag": "Academics",
        "sort_order": 8,
    },
    {
        "slug": "farewell",
        "name": "Farewell & Traditional Day",
        "description": "Sarees, kurtas, teary hugs, autograph shirts, and promises to stay connected forever.",
        "cover_url": "https://images.unsplash.com/photo-1517457373958-b7bdd4587205?auto=format&fit=crop&w=800&q=80",
        "tag": "Goodbye AU",
        "sort_order": 9,
    },
    {
        "slug": "misc",
        "name": "Unfiltered Candid Moments",
        "description": "Random hilarious snapshots, funny facial expressions, bloopers, and unplanned memories.",
        "cover_url": "https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&w=800&q=80",
        "tag": "Bloopers",
        "sort_order": 10,
    },
]

DEFAULT_INVITE_CODES = [
    "ANURAG2026",
    "MEMORIES2026",
    "BATCH2026",
    "GRADUATION2026",
]

def seed_albums(db: Session):
    """Seed default albums if none exist."""
    existing = db.query(Album).first()
    if existing:
        logger.info("Albums already seeded, skipping")
        return

    for album_data in ALBUMS:
        album = Album(**album_data)
        db.add(album)

    db.commit()
    logger.info(f"Seeded {len(ALBUMS)} albums")

def seed_invite_codes(db: Session):
    """Seed default invite codes if none exist."""
    from app.models.base import InviteCode
    existing = db.query(InviteCode).first()
    if existing:
        logger.info("Invite codes already seeded, skipping")
        return

    for code in DEFAULT_INVITE_CODES:
        invite = InviteCode(code=code)
        db.add(invite)

    db.commit()
    logger.info(f"Seeded {len(DEFAULT_INVITE_CODES)} invite codes")

def seed_system_config(db: Session):
    """Seed system configuration defaults."""
    existing = db.query(SystemConfig).filter(SystemConfig.key == "graduation_date").first()
    if not existing:
        config = SystemConfig(key="graduation_date", value="2026-05-15")
        db.add(config)
        db.commit()

def run_seed():
    """Run all seed operations."""
    db = SessionLocal()
    try:
        seed_albums(db)
        seed_invite_codes(db)
        seed_system_config(db)
        logger.info("Database seeding completed successfully")
    except Exception as e:
        logger.error(f"Seeding failed: {e}")
        db.rollback()
        raise
    finally:
        db.close()

if __name__ == "__main__":
    # Ensure tables exist
    Base.metadata.create_all(bind=engine)
    run_seed()
