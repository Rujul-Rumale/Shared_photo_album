import { useNavigate } from 'react-router-dom';

export default function AboutPage() {
  const navigate = useNavigate();

  const features = [
    { title: 'Non-Algorithmic', desc: 'No likes, comments, follower counts, or feeds. Pure nostalgic browsing.' },
    { title: 'Official Identity', desc: 'Every contributor signs in via official @anurag.edu.in accounts to maintain batch authenticity.' },
    { title: 'Curated Quality', desc: 'All submissions are reviewed by the batch committee before being permanently archived.' },
    { title: 'Graduation Time Capsule', desc: 'Sealed messages and letters unlocked on graduation day with a ceremonial reveal.' },
  ];

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-10">
      <div className="text-center space-y-4 border-b border-au-border pb-8">
        <span className="text-xs text-au-gold font-handwriting text-lg">Our Purpose</span>
        <h1 className="text-4xl font-normal text-white font-serif-title">Built for the Class of 2026</h1>
        <p className="text-xs sm:text-sm text-[#c7bbb0] leading-relaxed max-w-xl mx-auto">
          Anurag University Memories was created to solve a real issue: college memories scattered across temporary Instagram stories, lost WhatsApp groups, and full Google Drives.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {features.map((card, idx) => (
          <div key={idx} className="bg-au-card border border-au-border p-6 rounded-3xl space-y-2 shadow-xl">
            <h3 className="text-base font-bold text-au-gold font-serif-title">{card.title}</h3>
            <p className="text-xs text-[#c7bbb0] leading-relaxed">{card.desc}</p>
          </div>
        ))}
      </div>

      <div className="bg-gradient-to-r from-au-card to-au-card-hover border border-au-border rounded-3xl p-8 text-center space-y-4">
        <h2 className="text-2xl font-bold text-white font-serif-title">Ready to contribute?</h2>
        <p className="text-xs text-au-text-muted max-w-md mx-auto">
          Upload your favorite college memories to the batch archive. Every photo is moderated and permanently preserved.
        </p>
        <button
          onClick={() => navigate('/contribute')}
          className="bg-au-accent hover:bg-au-accent-hover text-white px-6 py-3 rounded-2xl text-xs font-bold transition shadow-lg"
        >
          Start Uploading
        </button>
      </div>
    </div>
  );
}
