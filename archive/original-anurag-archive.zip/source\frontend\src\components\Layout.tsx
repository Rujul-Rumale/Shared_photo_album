import { useState, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuthStore } from '@/store';
import {
  Shield, X, ArrowRight, ChevronDown,
  Home, Image, Clock, User, Info, Upload, Menu, Check, Pin
} from 'lucide-react';
import { cn } from '@/utils';
import AuthModal from './AuthModal';

interface LayoutProps {
  children: React.ReactNode;
}

const NAV_ITEMS = [
  { path: '/', label: 'Scrapbook Desk', icon: Home },
  { path: '/albums', label: 'Memory Vaults', icon: Image },
  { path: '/timecapsule', label: 'Time Capsule', icon: Clock },
  { path: '/contribute', label: 'Share Memory', icon: Upload },
  { path: '/about', label: 'Our Story', icon: Info },
];

export default function Layout({ children }: LayoutProps) {
  const { user, logout, isAuthenticated } = useAuthStore();
  const location = useLocation();
  const navigate = useNavigate();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);
  const [bannerDismissed, setBannerDismissed] = useState(false);
  const [authModalOpen, setAuthModalOpen] = useState(false);

  const isAdmin = user?.role === 'admin' || user?.role === 'curator';
  const showBanner = isAuthenticated && !user?.personal_email && !bannerDismissed;

  useEffect(() => {
    setMobileMenuOpen(false);
    setUserDropdownOpen(false);
  }, [location.pathname]);

  return (
    <div className="min-h-screen bg-au-bg text-au-text font-sans antialiased selection:bg-au-accent selection:text-white flex flex-col relative overflow-x-hidden">
      {/* Graduation Email Banner */}
      {showBanner && (
        <div className="bg-[#2a2421] border-b border-au-accent/40 text-au-gold px-4 py-2.5 text-xs flex items-center justify-between gap-3 shadow-inner">
          <div className="flex items-center gap-2 max-w-4xl overflow-hidden text-ellipsis whitespace-nowrap">
            <span className="bg-au-accent text-white font-bold px-2 py-0.5 rounded text-[10px] tracking-wider uppercase shrink-0">
              Graduation Notice
            </span>
            <span className="truncate">
              College email <strong className="text-white underline">{user.email}</strong> deactivates after graduation. Link a personal email to preserve your memories.
            </span>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => { navigate('/profile'); setBannerDismissed(true); }}
              className="bg-au-accent hover:bg-au-accent-hover text-white px-3 py-1 rounded-full text-[11px] font-bold transition flex items-center gap-1 shadow-sm"
            >
              <span>Link Personal Email</span>
              <ArrowRight className="w-3 h-3" />
            </button>
            <button onClick={() => setBannerDismissed(true)} className="text-au-text-muted hover:text-white p-1 rounded-lg">
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* Header */}
      <header className="sticky top-0 z-40 bg-au-bg/95 backdrop-blur-md border-b border-au-border shadow-xl">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16 sm:h-20 gap-4">
            {/* Logo */}
            <Link to="/" className="flex items-center gap-3 group text-left shrink-0">
              <div className="relative">
                <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-xl bg-au-accent text-white flex items-center justify-center font-bold text-lg sm:text-xl shadow-md group-hover:rotate-3 transition-transform font-serif-title border border-au-gold/40">
                  AU
                </div>
                <div className="absolute -bottom-1 -right-1 w-3.5 h-3.5 rounded-full bg-au-sage border-2 border-au-bg" title="Vault Active" />
              </div>
              <div className="flex flex-col">
                <div className="flex items-center gap-2">
                  <span className="font-normal text-lg sm:text-2xl tracking-tight text-au-text font-serif-title group-hover:text-au-gold transition-colors">
                    Anurag Memories
                  </span>
                  <span className="hidden sm:inline-block text-[10px] bg-au-card text-au-gold px-2 py-0.5 rounded-md font-handwriting font-bold border border-au-gold/20">
                    Class of '26
                  </span>
                </div>
                <p className="hidden md:block text-[11px] text-au-text-muted font-handwriting -mt-0.5">
                  The shared digital scrapbook for our college days
                </p>
              </div>
            </Link>

            {/* Desktop Nav */}
            <nav className="hidden lg:flex items-center space-x-1 bg-au-card p-1.5 rounded-2xl border border-au-border shadow-inner">
              {NAV_ITEMS.map((item) => {
                const isActive = location.pathname === item.path ||
                  (item.path !== '/' && location.pathname.startsWith(item.path));
                return (
                  <Link
                    key={item.path}
                    to={item.path}
                    className={cn(
                      "px-4 py-2 rounded-xl text-xs font-semibold transition-all duration-200",
                      isActive
                        ? "bg-au-accent text-white shadow-md font-bold"
                        : "text-au-text-muted hover:text-au-text hover:bg-au-card-hover"
                    )}
                  >
                    {item.label}
                  </Link>
                );
              })}
            </nav>

            {/* Right Actions */}
            <div className="flex items-center gap-2 sm:gap-3">
              {isAdmin && (
                <Link
                  to="/admin"
                  className={cn(
                    "px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition shadow-sm",
                    location.pathname === '/admin'
                      ? "bg-au-accent text-white"
                      : "bg-au-accent/15 text-au-gold hover:bg-au-accent/25 border border-au-accent/30"
                  )}
                >
                  <Shield className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Curation</span>
                </Link>
              )}

              {isAuthenticated ? (
                <div className="relative">
                  <button
                    onClick={() => setUserDropdownOpen(!userDropdownOpen)}
                    className="flex items-center gap-2 p-1.5 pr-2.5 rounded-2xl bg-au-card border border-au-border hover:border-au-accent/50 transition shadow-sm"
                  >
                    <img
                      src={user?.avatar_url || `https://ui-avatars.com/api/?name=${encodeURIComponent(user?.name || 'U')}&background=b87352&color=fff`}
                      alt={user?.name}
                      className="w-7 h-7 sm:w-8 sm:h-8 rounded-xl object-cover ring-2 ring-au-accent/60"
                    />
                    <span className="hidden sm:inline-block text-xs font-medium text-au-text max-w-[100px] truncate">
                      {user?.name?.split(' ')[0]}
                    </span>
                    <ChevronDown className="w-3.5 h-3.5 text-au-text-muted" />
                  </button>

                  {userDropdownOpen && (
                    <div
                      className="absolute right-0 mt-2 w-56 bg-au-card border border-au-border rounded-2xl shadow-2xl p-2 z-50 space-y-1 text-xs"
                      onMouseLeave={() => setUserDropdownOpen(false)}
                    >
                      <div className="px-3 py-2 border-b border-au-border text-left">
                        <p className="font-bold text-white truncate">{user?.name}</p>
                        <p className="text-[10px] text-au-text-muted truncate">{user?.email}</p>
                      </div>
                      <Link
                        to="/profile"
                        className="w-full text-left px-3 py-2 rounded-xl hover:bg-au-card-hover text-au-text transition flex items-center gap-2 block"
                      >
                        <Pin className="w-3.5 h-3.5 text-au-gold" />
                        <span>My Account & Uploads</span>
                      </Link>
                      <button
                        onClick={() => { logout(); setUserDropdownOpen(false); }}
                        className="w-full text-left px-3 py-2 rounded-xl hover:bg-rose-950/30 text-rose-300 transition flex items-center gap-2 border-t border-au-border mt-1"
                      >
                        <X className="w-3.5 h-3.5" />
                        <span>Sign Out</span>
                      </button>
                    </div>
                  )}
                </div>
              ) : (
                <button
                  onClick={() => setAuthModalOpen(true)}
                  className="bg-au-accent hover:bg-au-accent-hover text-white px-4 py-2 sm:px-5 sm:py-2.5 rounded-2xl text-xs font-bold transition shadow-lg shadow-amber-950/30"
                >
                  Sign In
                </button>
              )}

              {/* Mobile Menu Button */}
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="lg:hidden p-2 rounded-xl bg-au-card border border-au-border text-au-text hover:text-au-gold transition"
              >
                {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="lg:hidden bg-[#241f1c] border-b border-au-border px-4 py-4 space-y-3 shadow-2xl">
            <div className="text-[11px] font-handwriting text-au-gold px-2">Navigation Scrapbook Tabs</div>
            <div className="grid grid-cols-2 gap-2">
              {[...NAV_ITEMS, ...(isAdmin ? [{ path: '/admin', label: 'Curation Room', icon: Shield }] : []), { path: '/profile', label: 'My Profile', icon: User }].map((item) => {
                const isActive = location.pathname === item.path || (item.path !== '/' && location.pathname.startsWith(item.path));
                const Icon = item.icon || Home;
                return (
                  <Link
                    key={item.path}
                    to={item.path}
                    className={cn(
                      "p-2.5 rounded-xl text-xs font-semibold text-left transition flex items-center justify-between",
                      isActive
                        ? "bg-au-accent text-white font-bold shadow-md"
                        : "text-au-text-muted bg-au-bg border border-au-border hover:text-white"
                    )}
                  >
                    <span className="flex items-center gap-2">
                      <Icon className="w-3.5 h-3.5" />
                      {item.label}
                    </span>
                    {isActive && <Check className="w-3.5 h-3.5 text-white" />}
                  </Link>
                );
              })}
            </div>
          </div>
        )}
      </header>

      {/* Main Content */}
      <main className="flex-1">
        {children}
      </main>

      {/* Footer */}
      <footer className="bg-au-bg-dark border-t border-au-border text-au-text-muted py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="space-y-3 md:col-span-2">
              <div className="flex items-center gap-3 text-white font-serif-title text-xl">
                <div className="w-8 h-8 rounded-xl bg-au-accent text-white flex items-center justify-center font-bold text-sm">AU</div>
                Anurag University Memory Scrapbook
              </div>
              <p className="text-xs text-au-text-muted leading-relaxed max-w-md">
                A non-algorithmic, curated digital scrapbook created to preserve authentic college memories for the graduating class of 2022–2026. Every photograph and message is saved safely for decades to come.
              </p>
            </div>
            <div className="space-y-3">
              <h4 className="text-white text-xs font-bold uppercase tracking-wider font-serif-title text-au-gold">Memory Stacks</h4>
              <ul className="space-y-2 text-xs">
                <li><Link to="/albums" className="hover:text-au-gold transition">Photo Stacks</Link></li>
                <li><Link to="/timecapsule" className="hover:text-au-gold transition">Graduation Time Capsule</Link></li>
                <li><Link to="/contribute" className="hover:text-au-gold transition">Submit Photographs</Link></li>
              </ul>
            </div>
            <div className="space-y-3">
              <h4 className="text-white text-xs font-bold uppercase tracking-wider font-serif-title text-au-gold">Batch Committee</h4>
              <p className="text-xs text-au-text-muted leading-relaxed">Need a photo removed or transferred to another vault?</p>
              <a href="mailto:archive@anurag.edu.in" className="text-xs text-au-gold hover:underline block font-medium">
                archive@anurag.edu.in
              </a>
            </div>
          </div>
          <div className="pt-8 border-t border-au-border flex flex-col sm:flex-row items-center justify-between text-xs text-au-text-dim gap-4">
            <p>© 2022–2026 Anurag University Batch Committee. Built with nostalgia & care.</p>
            <p className="font-handwriting text-base text-au-gold">"Once an Anuragian, always an Anuragian."</p>
          </div>
        </div>
      </footer>

      {/* Auth Modal */}
      {authModalOpen && <AuthModal onClose={() => setAuthModalOpen(false)} />}
    </div>
  );
}
