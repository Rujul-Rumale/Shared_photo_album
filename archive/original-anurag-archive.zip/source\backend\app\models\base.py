from sqlalchemy import Column, String, DateTime, Boolean, Integer, Text, ForeignKey, Enum, BigInteger
from sqlalchemy.dialects.postgresql import UUID, JSONB
from sqlalchemy.orm import declarative_base, relationship
from sqlalchemy.sql import func
import uuid
import enum

Base = declarative_base()

class UserRole(str, enum.Enum):
    STUDENT = "student"
    ADMIN = "admin"
    CURATOR = "curator"

class MediaStatus(str, enum.Enum):
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"

class MediaType(str, enum.Enum):
    PHOTO = "photo"
    VIDEO = "video"

class CapsuleStatus(str, enum.Enum):
    OPEN = "open"
    SEALED = "sealed"
    REVEALED = "revealed"

class User(Base):
    __tablename__ = "users"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    email = Column(String(255), unique=True, nullable=False, index=True)
    college_email = Column(String(255), unique=True, nullable=False, index=True)
    personal_email = Column(String(255), nullable=True)
    name = Column(String(255), nullable=False)
    avatar_url = Column(String(500), nullable=True)
    role = Column(Enum(UserRole), default=UserRole.STUDENT, nullable=False)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    last_login = Column(DateTime(timezone=True), nullable=True)

    # Relationships
    uploads = relationship("Media", back_populates="contributor")
    capsule_entries = relationship("TimeCapsuleEntry", back_populates="author")
    invite_code_used = relationship("InviteCode", back_populates="used_by", uselist=False)

class Album(Base):
    __tablename__ = "albums"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    slug = Column(String(100), unique=True, nullable=False, index=True)
    name = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    cover_url = Column(String(500), nullable=True)
    tag = Column(String(100), nullable=True)
    sort_order = Column(Integer, default=0)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    media = relationship("Media", back_populates="album")

class Media(Base):
    __tablename__ = "media"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    album_id = Column(UUID(as_uuid=True), ForeignKey("albums.id"), nullable=False)
    contributor_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False)

    original_filename = Column(String(255), nullable=False)
    storage_path = Column(String(500), nullable=False)  # Path on Raspberry Pi HDD
    thumbnail_path = Column(String(500), nullable=True)
    mime_type = Column(String(100), nullable=False)
    file_size = Column(BigInteger, nullable=False)
    checksum = Column(String(64), nullable=True)  # SHA-256

    media_type = Column(Enum(MediaType), nullable=False)
    status = Column(Enum(MediaStatus), default=MediaStatus.PENDING, nullable=False)

    note = Column(Text, nullable=True)
    width = Column(Integer, nullable=True)
    height = Column(Integer, nullable=True)
    duration = Column(Integer, nullable=True)  # seconds for video

    created_at = Column(DateTime(timezone=True), server_default=func.now())
    approved_at = Column(DateTime(timezone=True), nullable=True)
    approved_by_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)

    album = relationship("Album", back_populates="media")
    contributor = relationship("User", foreign_keys=[contributor_id], back_populates="uploads")
    approved_by = relationship("User", foreign_keys=[approved_by_id])

class TimeCapsuleEntry(Base):
    __tablename__ = "time_capsule_entries"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    author_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False)

    prompt = Column(String(255), nullable=False)
    message = Column(Text, nullable=False)
    ink_color = Column(String(7), default="#2b2623")

    # Optional media attachments
    media_id = Column(UUID(as_uuid=True), ForeignKey("media.id"), nullable=True)

    status = Column(Enum(CapsuleStatus), default=CapsuleStatus.OPEN, nullable=False)
    sealed_at = Column(DateTime(timezone=True), nullable=True)

    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    author = relationship("User", back_populates="capsule_entries")
    media = relationship("Media")

class InviteCode(Base):
    __tablename__ = "invite_codes"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    code = Column(String(50), unique=True, nullable=False, index=True)
    is_used = Column(Boolean, default=False)
    used_by_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    created_by_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    used_at = Column(DateTime(timezone=True), nullable=True)

    used_by = relationship("User", foreign_keys=[used_by_id], back_populates="invite_code_used")
    created_by = relationship("User", foreign_keys=[created_by_id])

class SystemConfig(Base):
    __tablename__ = "system_config"

    id = Column(Integer, primary_key=True)
    key = Column(String(100), unique=True, nullable=False)
    value = Column(Text, nullable=True)
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
