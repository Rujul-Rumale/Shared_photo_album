import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Lock, Sparkles, Check } from 'lucide-react';
import { capsuleApi } from '@/api';
import { useAuthStore } from '@/store';
import { getDaysUntil } from '@/utils';
import type { CapsuleEntry } from '@/types';

const PROMPTS = [
  'Letter to Future Self',
  'Message to the Class of 2026',
  'Where do you see yourself in 5 years?',
  'Unfiltered College Memory',
];

const INK_COLORS = [
  { name: 'Charcoal Coffee', hex: '#2b2623' },
  { name: 'Roasted Copper', hex: '#b87352' },
  { name: 'Eucalyptus Sage', hex: '#8a9a86' },
];

export default function CapsulePage() {
  const { user, isAuthenticated } = useAuthStore();
  const queryClient = useQueryClient();
  const [authorName, setAuthorName] = useState(user?.name || '');
  const [rollNumber, setRollNumber] = useState('');
  const [selectedPrompt, setSelectedPrompt] = useState(PROMPTS[0]);
  const [message, setMessage] = useState('');
  const [selectedInk, setSelectedInk] = useState('#2b2623');
  const [isRevealed, setIsRevealed] = useState(false);
  const [submittedSuccess, setSubmittedSuccess] = useState(false);

  const { data: statusData } = useQuery({
    queryKey: ['capsule-status'],
    queryFn: () => capsuleApi.getStatus(),
  });

  const { data: entriesData } = useQuery({
    queryKey: ['capsule-entries'],
    queryFn: () => capsuleApi.list(),
    enabled: isAuthenticated,
  });

  const createMutation = useMutation({
    mutationFn: capsuleApi.create,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['capsule-entries'] });
      setMessage('');
      setSubmittedSuccess(true);
      setTimeout(() => setSubmittedSuccess(false), 4000);
    },
  });

  const entries: CapsuleEntry[] = entriesData?.data || [];
  const graduationDate = statusData?.data?.graduation_date || '2026-05-15';
  const daysUntil = getDaysUntil(graduationDate);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim() || !rollNumber.trim()) return;
    createMutation.mutate({
      prompt: selectedPrompt,
      message: message.trim(),
      ink_color: selectedInk,
    });
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-12">
      {/* Header */}
      <div className="text-center space-y-4 max-w-2xl mx-auto border-b border-au-border pb-8">
        <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-au-gold/10 text-au-gold text-xs font-handwriting text-base">
          <Lock className="w-3.5 h-3.5" />
          <span>Sealed Vault • Class of 2026</span>
        </div>
        <h1 className="text-3xl sm:text-5xl font-normal text-white font-serif-title">
          Graduation Time Capsule
        </h1>
        <p className="text-xs sm:text-sm text-[#c7bbb0] leading-relaxed">
          Write a signed letter to your future self or leave a farewell note for the batch. Encrypted and locked until Graduation Day.
        </p>
      </div>

      {/* Countdown */}
      <div className="bg-au-card border border-au-border rounded-3xl p-6 sm:p-8 flex flex-col sm:flex-row items-center justify-between gap-6 shadow-xl">
        <div className="space-y-1 text-center sm:text-left">
          <span className="text-xs text-au-gold font-handwriting text-lg">Graduation Reveal Ceremony</span>
          <div className="text-xl font-bold text-white font-serif-title">May 2026 Vault Unlock</div>
        </div>

        <div className="flex gap-3 text-center">
          {[
            { num: String(Math.floor(daysUntil / 30)).padStart(2, '0'), unit: 'MONTHS' },
            { num: String(daysUntil % 30).padStart(2, '0'), unit: 'DAYS' },
            { num: '14', unit: 'HOURS' },
            { num: '32', unit: 'MINS' },
          ].map((t, idx) => (
            <div key={idx} className="bg-au-bg border border-au-border px-3.5 py-2 rounded-2xl min-w-[64px]">
              <div className="text-xl font-bold text-au-gold font-serif-title">{t.num}</div>
              <div className="text-[9px] text-au-text-dim font-semibold">{t.unit}</div>
            </div>
          ))}
        </div>

        <button
          onClick={() => setIsRevealed(!isRevealed)}
          className="bg-au-card-hover hover:bg-[#3f3732] text-au-gold border border-au-border px-4 py-2 rounded-2xl text-xs font-semibold transition"
        >
          {isRevealed ? 'Re-Seal Vault' : 'Test Ceremonial Reveal'}
        </button>
      </div>

      {/* Compose Form */}
      {isAuthenticated && (
        <div className="bg-au-card border border-au-border rounded-3xl p-6 sm:p-8 space-y-6 shadow-xl">
          <div className="flex items-center gap-2 border-b border-au-border pb-4">
            <Sparkles className="w-5 h-5 text-au-gold" />
            <h2 className="text-lg font-bold text-white font-serif-title">Deposit Capsule Letter</h2>
          </div>

          {submittedSuccess && (
            <div className="bg-emerald-950/40 border border-emerald-500/40 text-emerald-300 p-4 rounded-2xl text-xs flex items-center gap-2">
              <Check className="w-4 h-4 text-emerald-400" />
              <span>Letter securely sealed and added to the graduation capsule!</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs text-au-text-muted mb-1.5 font-medium">Full Name</label>
                <input
                  type="text"
                  required
                  value={authorName}
                  onChange={(e) => setAuthorName(e.target.value)}
                  placeholder="Rahul Sharma"
                  className="w-full bg-au-bg border border-au-border rounded-2xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-au-accent"
                />
              </div>
              <div>
                <label className="block text-xs text-au-text-muted mb-1.5 font-medium">AU Roll Number / ID</label>
                <input
                  type="text"
                  required
                  value={rollNumber}
                  onChange={(e) => setRollNumber(e.target.value)}
                  placeholder="2201A0501"
                  className="w-full bg-au-bg border border-au-border rounded-2xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-au-accent uppercase"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs text-au-text-muted mb-1.5 font-medium">Select Letter Topic</label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {PROMPTS.map((p) => (
                  <button
                    type="button"
                    key={p}
                    onClick={() => setSelectedPrompt(p)}
                    className={`px-3.5 py-2.5 rounded-2xl text-xs font-medium text-left transition ${
                      selectedPrompt === p
                        ? 'bg-au-accent text-white font-bold'
                        : 'bg-au-bg text-au-text-muted hover:text-white border border-au-border'
                    }`}
                  >
                    {p}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <div className="flex justify-between items-center mb-1.5">
                <label className="block text-xs text-au-text-muted font-medium">Your Letter / Message</label>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] text-au-text-dim">Ink:</span>
                  {INK_COLORS.map((c) => (
                    <button
                      key={c.hex}
                      type="button"
                      onClick={() => setSelectedInk(c.hex)}
                      className={`w-4 h-4 rounded-full transition ${selectedInk === c.hex ? 'ring-2 ring-white scale-110' : 'opacity-60'}`}
                      style={{ backgroundColor: c.hex }}
                      title={c.name}
                    />
                  ))}
                </div>
              </div>
              <textarea
                rows={5}
                required
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Write your letter here... It will remain permanently attributed to your identity."
                className="w-full bg-au-polaroid border border-[#d8cdbf] rounded-2xl p-4 text-sm font-handwriting focus:outline-none focus:border-au-accent"
                style={{ color: selectedInk }}
              />
            </div>

            <button
              type="submit"
              disabled={createMutation.isPending}
              className="w-full bg-au-accent hover:bg-au-accent-hover disabled:bg-au-card-hover text-white py-3.5 rounded-2xl text-xs font-bold transition shadow-lg shadow-amber-950/30 flex items-center justify-center gap-2"
            >
              <Lock className="w-4 h-4" />
              <span>{createMutation.isPending ? 'Sealing...' : 'Seal Letter into Time Capsule'}</span>
            </button>
          </form>
        </div>
      )}

      {/* Entries */}
      <div className="space-y-6">
        <div className="flex items-center justify-between border-b border-au-border pb-4">
          <h2 className="text-xl font-bold text-white font-serif-title">
            Capsule Submissions ({entries.length})
          </h2>
          <span className="text-xs font-handwriting text-au-gold text-base">
            {isRevealed ? 'Revealed View Active' : 'Encrypted & Sealed'}
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {entries.map((item) => (
            <div key={item.id} className="bg-au-polaroid border border-[#d8cdbf] text-au-polaroid-text rounded-3xl p-6 space-y-4 relative overflow-hidden shadow-xl">
              <div className="flex items-center justify-between text-xs text-[#73655b] border-b border-[#e8ded1] pb-3">
                <span className="text-au-accent font-bold font-serif-title">{item.prompt}</span>
                <span>{new Date(item.created_at).toLocaleDateString()}</span>
              </div>

              {isRevealed ? (
                <div className="space-y-3">
                  <p className="font-handwriting text-lg leading-relaxed" style={{ color: item.ink_color || '#2b2623' }}>
                    "{item.message}"
                  </p>
                  <div className="pt-2 flex items-center justify-between border-t border-[#e8ded1] text-xs text-[#73655b]">
                    <span className="font-bold text-au-polaroid-text">— {item.author_name} ({item.author_roll_no || 'N/A'})</span>
                  </div>
                </div>
              ) : (
                <div className="py-8 text-center space-y-2 bg-[#f0ebe1] rounded-2xl border border-[#d8cdbf]">
                  <Lock className="w-6 h-6 text-au-accent mx-auto" />
                  <p className="text-xs text-au-polaroid-text font-bold">Encrypted & Sealed</p>
                  <p className="text-[11px] text-[#73655b]">Signed by {item.author_name}</p>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
