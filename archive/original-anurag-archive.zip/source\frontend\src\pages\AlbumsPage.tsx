import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { Search, Upload } from 'lucide-react';
import { albumsApi } from '@/api';
import PolaroidCard from '@/components/PolaroidCard';
import type { Album } from '@/types';

export default function AlbumsPage() {
  const [selectedTag, setSelectedTag] = useState('ALL');
  const [searchQuery, setSearchQuery] = useState('');

  const { data: albumsData } = useQuery({
    queryKey: ['albums'],
    queryFn: () => albumsApi.list(),
  });

  const albums: Album[] = albumsData?.data || [];

  const tags = ['ALL', ...Array.from(new Set(albums.map((a) => a.tag).filter(Boolean)))];

  const filtered = albums.filter((a) => {
    const matchesTag = selectedTag === 'ALL' || a.tag === selectedTag;
    const matchesSearch = !searchQuery ||
      a.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (a.description?.toLowerCase() || '').includes(searchQuery.toLowerCase());
    return matchesTag && matchesSearch;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-10">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-au-border pb-6">
        <div>
          <span className="text-xs text-au-gold font-handwriting text-lg">Curated Memory Vaults</span>
          <h1 className="text-2xl sm:text-4xl font-normal text-white font-serif-title">College Photo Stacks</h1>
          <p className="text-xs text-[#c7bbb0] mt-1 max-w-xl">
            Explore categorized scrapbook photo stacks from 2022 to 2026. Every memory is moderated and signed.
          </p>
        </div>
        <Link
          to="/contribute"
          className="bg-au-accent hover:bg-au-accent-hover text-white px-5 py-2.5 rounded-2xl text-xs font-bold transition shadow-lg shadow-amber-950/30 flex items-center gap-2 self-start"
        >
          <Upload className="w-4 h-4" />
          <span>Share a Memory</span>
        </Link>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4">
        <div className="flex flex-wrap gap-2">
          {tags.map((tag) => (
            <button
              key={tag}
              onClick={() => setSelectedTag(tag)}
              className={`px-3.5 py-1.5 rounded-full text-xs font-medium transition ${
                selectedTag === tag
                  ? 'bg-au-accent text-white'
                  : 'bg-au-card text-au-text-muted hover:text-white border border-au-border'
              }`}
            >
              {tag}
            </button>
          ))}
        </div>

        <div className="relative w-full sm:w-64">
          <Search className="w-4 h-4 text-au-text-muted absolute left-3.5 top-3" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search photo stacks..."
            className="w-full bg-au-card border border-au-border rounded-2xl pl-10 pr-4 py-2.5 text-xs text-white placeholder-au-text-dim focus:outline-none focus:border-au-accent"
          />
        </div>
      </div>

      {/* Album Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {filtered.map((album) => (
          <PolaroidCard key={album.id} album={album} href={`/albums/${album.slug}`} />
        ))}
      </div>
    </div>
  );
}
