ORIGINAL ANURAG ARCHIVE
=======================
Preserved: 2026-10-10
This zip keeps the original, pre-template version of the project
("Anurag University Memories") before it was generalized into the
Shared Album template.

Contents:
  source/      Pristine application source (FastAPI backend + React
               frontend, Docker/Caddy configs, docs). No node_modules,
               venv, dist, or database files.
  specs/       Original product specs:
                 01_Product_Vision.md
                 02_UI_UX_Specification.md
                 03_Master_Prompt.md
  prototypes/  Original single-file HTML scrapbook prototypes plus
               their texture images.

The generalized, reusable version lives in: shared-album-template/
