# MASTER PROMPT FOR KIMI K2.6

Act as a principal product designer, staff frontend engineer, staff
backend engineer, DevOps engineer and UI/UX designer.

Build a production-ready web application called **Anurag University
Memories**.

Requirements:

## Stack

-   React + TypeScript
-   Tailwind CSS
-   FastAPI
-   PostgreSQL (or SQLite in development)
-   Docker Compose
-   Caddy or Nginx
-   Google OAuth
-   JWT or secure HTTP-only session cookies
-   Responsive/mobile-first

## Authentication

-   Google Sign-In.
-   Only @anurag.edu.in accounts may register.
-   Registration additionally requires a one-time invite code.
-   After first registration, invite code is never needed again.
-   One day before graduation, email users asking them to link a
    personal Google account. Preserve user identity using immutable
    UUIDs rather than email.

## Albums

Support curated albums. Uploads go into moderation. Nothing appears
publicly until approved.

## Uploads

Support: - Drag/drop - Multi-select - Preview - Progress - Large video
uploads - Resume-friendly architecture - Store originals

## Time Capsule

Accept: - Photos - Videos - Signed messages

No anonymous content. Lock editing after sealing. Reveal only on
graduation with a dedicated opening experience.

## Admin

Pending queue Album management Invite management Storage dashboard User
management

## Storage

Frontend/API on Oracle Always Free. Original media stored on Raspberry
Pi external HDD over Tailscale.

## Deliverables

Generate: 1. Complete project structure. 2. Database schema. 3. API. 4.
React frontend. 5. Admin dashboard. 6. Docker configuration. 7.
Authentication. 8. Responsive UI. 9. Seed data. 10. README with
deployment instructions.

Code should be production-quality, modular, typed, documented, and easy
to extend.
