import { X, Download } from 'lucide-react';
import type { MediaItem, Album } from '@/types';

interface LightboxModalProps {
  item: MediaItem;
  album?: Album;
  onClose: () => void;
}

export default function LightboxModal({ item, album, onClose }: LightboxModalProps) {
  return (
    <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4" onClick={onClose}>
      <div 
        className="bg-au-card border border-au-border max-w-4xl w-full rounded-3xl overflow-hidden flex flex-col md:flex-row relative shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <button onClick={onClose} className="absolute top-4 right-4 z-10 bg-black/60 text-white p-2 rounded-full hover:bg-black">
          <X className="w-5 h-5" />
        </button>

        <div className="flex-1 bg-black flex items-center justify-center p-4">
          <img
            src={item.storage_path}
            alt={item.note || 'AU Memory'}
            className="max-h-[70vh] w-auto object-contain rounded-xl"
          />
        </div>

        <div className="w-full md:w-80 p-6 space-y-4 bg-au-card border-t md:border-t-0 md:border-l border-au-border flex flex-col justify-between">
          <div className="space-y-4">
            <span className="text-[11px] bg-au-accent/20 text-au-gold px-3 py-1 rounded-full font-bold">
              {album?.name || 'Vault Media'}
            </span>

            <p className="font-handwriting text-xl text-white leading-snug">{item.note || 'No caption provided'}</p>

            <div className="space-y-2 text-xs text-au-text-muted border-t border-au-border pt-3">
              <div>
                <span className="text-au-text-dim">Contributor:</span>
                <p className="text-white font-bold">{item.contributor_name}</p>
              </div>
              <div>
                <span className="text-au-text-dim">Date Uploaded:</span>
                <p className="text-white font-bold">{new Date(item.created_at).toLocaleDateString()}</p>
              </div>
            </div>
          </div>

          <a
            href={item.storage_path}
            target="_blank"
            rel="noreferrer"
            className="w-full bg-au-bg hover:bg-au-card-hover text-au-gold py-2.5 rounded-2xl text-xs font-semibold text-center block border border-au-border flex items-center justify-center gap-2"
          >
            <Download className="w-4 h-4" />
            Download High-Res Original
          </a>
        </div>
      </div>
    </div>
  );
}
