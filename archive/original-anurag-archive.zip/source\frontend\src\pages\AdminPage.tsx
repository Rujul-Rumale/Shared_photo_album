import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { Shield, Check, X, Users, Image, Video, Clock, HardDrive, Lock, Plus } from 'lucide-react';
import { useAuthStore } from '@/store';
import { adminApi, mediaApi, invitesApi } from '@/api';
import type { DashboardStats, MediaItem, InviteCode } from '@/types';

export default function AdminPage() {
  const { user } = useAuthStore();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState<'queue' | 'invites' | 'stats'>('queue');

  // Redirect non-admin users
  if (!user || (user.role !== 'admin' && user.role !== 'curator')) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-20 text-center">
        <Shield className="w-12 h-12 text-au-text-muted mx-auto mb-4" />
        <h2 className="text-xl font-bold text-white font-serif-title mb-2">Access Denied</h2>
        <p className="text-xs text-au-text-muted">This area is restricted to batch committee curators.</p>
      </div>
    );
  }

  const { data: statsData } = useQuery({
    queryKey: ['admin-stats'],
    queryFn: () => adminApi.getStats(),
  });

  const { data: pendingData } = useQuery({
    queryKey: ['pending-media'],
    queryFn: () => mediaApi.listPending(),
  });

  const { data: invitesData } = useQuery({
    queryKey: ['invite-codes'],
    queryFn: () => invitesApi.list(),
  });

  const stats: DashboardStats = statsData?.data || {
    total_users: 0, total_photos: 0, total_videos: 0,
    pending_moderation: 0, total_albums: 0, storage_used_bytes: 0,
    capsule_entries: 0, active_invite_codes: 0,
  };

  const pendingItems: MediaItem[] = pendingData?.data?.items || [];
  const inviteCodes: InviteCode[] = invitesData?.data || [];

  const approveMutation = useMutation({
    mutationFn: (id: string) => mediaApi.moderate(id, { status: 'approved' }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['pending-media'] });
      queryClient.invalidateQueries({ queryKey: ['admin-stats'] });
    },
  });

  const rejectMutation = useMutation({
    mutationFn: (id: string) => mediaApi.moderate(id, { status: 'rejected' }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['pending-media'] });
      queryClient.invalidateQueries({ queryKey: ['admin-stats'] });
    },
  });

  const generateMutation = useMutation({
    mutationFn: () => invitesApi.generate(5),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['invite-codes'] });
      queryClient.invalidateQueries({ queryKey: ['admin-stats'] });
    },
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 border-b border-au-border pb-6">
        <div>
          <span className="text-xs text-au-gold font-handwriting text-lg">Batch Committee Room</span>
          <h1 className="text-3xl font-normal text-white font-serif-title">Curation Room</h1>
        </div>

        <div className="flex gap-2">
          {(['queue', 'invites', 'stats'] as const).map((t) => (
            <button
              key={t}
              onClick={() => setActiveTab(t)}
              className={`px-4 py-2 rounded-2xl text-xs font-semibold capitalize transition ${
                activeTab === t
                  ? 'bg-au-accent text-white'
                  : 'bg-au-card text-au-text-muted border border-au-border'
              }`}
            >
              {t === 'queue' ? `Moderation Queue (${pendingItems.length})` : t === 'invites' ? 'Invite Stamps' : 'Dashboard'}
            </button>
          ))}
        </div>
      </div>

      {/* Stats Overview (always visible at top) */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { icon: Users, label: 'Users', value: stats.total_users, color: 'text-au-gold' },
          { icon: Image, label: 'Photos', value: stats.total_photos, color: 'text-emerald-400' },
          { icon: Video, label: 'Videos', value: stats.total_videos, color: 'text-blue-400' },
          { icon: Clock, label: 'Pending', value: stats.pending_moderation, color: 'text-amber-400' },
        ].map((stat, idx) => (
          <div key={idx} className="bg-au-card border border-au-border p-4 rounded-2xl flex items-center gap-3">
            <stat.icon className={`w-8 h-8 ${stat.color}`} />
            <div>
              <div className="text-xl font-bold text-white font-serif-title">{stat.value}</div>
              <div className="text-[10px] text-au-text-muted">{stat.label}</div>
            </div>
          </div>
        ))}
      </div>

      {/* Queue Tab */}
      {activeTab === 'queue' && (
        <div className="space-y-6">
          {pendingItems.length === 0 ? (
            <div className="bg-au-card border border-au-border p-12 rounded-3xl text-center space-y-2">
              <Check className="w-8 h-8 text-emerald-400 mx-auto" />
              <h3 className="text-white font-bold font-serif-title">Moderation Queue Clear</h3>
              <p className="text-xs text-au-text-muted">All submitted memories have been reviewed and added to vaults.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {pendingItems.map((item) => (
                <div key={item.id} className="polaroid-card p-4 rounded-2xl space-y-4">
                  <img src={item.storage_path} alt="pending" className="w-full h-48 object-cover rounded-xl" />
                  <div className="space-y-1 text-xs text-au-polaroid-text">
                    <p className="font-handwriting text-base font-bold">{item.note || 'No note provided'}</p>
                    <p className="text-[#73655b]">By: {item.contributor_name}</p>
                  </div>

                  <div className="flex items-center gap-2 pt-2 border-t border-zinc-200">
                    <button
                      onClick={() => approveMutation.mutate(item.id)}
                      disabled={approveMutation.isPending}
                      className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white py-2 rounded-xl text-xs font-bold transition"
                    >
                      Approve
                    </button>
                    <button
                      onClick={() => rejectMutation.mutate(item.id)}
                      disabled={rejectMutation.isPending}
                      className="flex-1 bg-rose-100 hover:bg-rose-200 text-rose-800 py-2 rounded-xl text-xs font-bold transition"
                    >
                      Reject
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Invites Tab */}
      {activeTab === 'invites' && (
        <div className="bg-au-card border border-au-border rounded-3xl p-6 space-y-6">
          <div className="flex items-center justify-between border-b border-au-border pb-4">
            <h2 className="text-lg font-bold text-white font-serif-title">One-Time Registration Codes</h2>
            <button
              onClick={() => generateMutation.mutate()}
              disabled={generateMutation.isPending}
              className="bg-au-accent hover:bg-au-accent-hover text-white px-4 py-2 rounded-2xl text-xs font-bold transition flex items-center gap-2"
            >
              <Plus className="w-4 h-4" />
              {generateMutation.isPending ? 'Generating...' : 'Generate Stamp'}
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            {inviteCodes.map((inv, idx) => (
              <div key={idx} className="bg-au-bg border border-au-border p-4 rounded-2xl flex items-center justify-between">
                <span className="font-bold text-au-gold text-sm tracking-wide">{inv.code}</span>
                <span className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full ${
                  inv.is_used ? 'bg-zinc-800 text-zinc-500' : 'bg-emerald-950 text-emerald-300 border border-emerald-500/30'
                }`}>
                  {inv.is_used ? 'SPENT' : 'ACTIVE'}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Stats Tab */}
      {activeTab === 'stats' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-au-card border border-au-border p-6 rounded-3xl space-y-4">
            <h3 className="text-lg font-bold text-white font-serif-title">Storage Health</h3>
            <div className="space-y-3">
              <div className="flex justify-between text-xs">
                <span className="text-au-text-muted">Total Storage</span>
                <span className="text-white font-bold">{(stats.storage_used_bytes / (1024**3)).toFixed(2)} GB used</span>
              </div>
              <div className="w-full bg-au-bg h-2 rounded-full overflow-hidden">
                <div className="bg-au-accent h-full" style={{ width: `${Math.min((stats.storage_used_bytes / (500 * 1024**3)) * 100, 100)}%` }} />
              </div>
              <p className="text-[10px] text-au-text-dim">External HDD on Raspberry Pi via Tailscale</p>
            </div>
          </div>

          <div className="bg-au-card border border-au-border p-6 rounded-3xl space-y-4">
            <h3 className="text-lg font-bold text-white font-serif-title">Capsule Status</h3>
            <div className="space-y-2 text-xs">
              <div className="flex justify-between">
                <span className="text-au-text-muted">Total Entries</span>
                <span className="text-white font-bold">{stats.capsule_entries}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-au-text-muted">Active Invite Codes</span>
                <span className="text-white font-bold">{stats.active_invite_codes}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-au-text-muted">Total Albums</span>
                <span className="text-white font-bold">{stats.total_albums}</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
