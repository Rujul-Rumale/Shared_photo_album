import { useState } from 'react';
import { X } from 'lucide-react';
import { useAuthStore } from '@/store';
import { authApi } from '@/api';

interface AuthModalProps {
  onClose: () => void;
}

export default function AuthModal({ onClose }: AuthModalProps) {
  const [email, setEmail] = useState('student@anurag.edu.in');
  const [inviteCode, setInviteCode] = useState('ANURAG2026');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { login } = useAuthStore();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    if (!email.trim().toLowerCase().endsWith('@anurag.edu.in')) {
      setError('Access Denied: Only official @anurag.edu.in college accounts can register.');
      setLoading(false);
      return;
    }

    try {
      // In production, this would use Google OAuth
      // For demo, simulate with a mock token
      const mockGoogleToken = `mock-google-token-${Date.now()}`;
      const response = await authApi.googleAuth(mockGoogleToken, inviteCode.trim());

      if (response.data?.access_token && response.data?.user) {
        login(response.data.user, response.data.access_token);
        onClose();
      }
    } catch (err: any) {
      setError(err.response?.data?.detail || 'Authentication failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-au-card border border-au-border w-full max-w-md rounded-3xl p-6 sm:p-8 space-y-6 relative shadow-2xl">
        <button onClick={onClose} className="absolute top-4 right-4 text-au-text-muted hover:text-white">
          <X className="w-5 h-5" />
        </button>

        <div className="space-y-1">
          <span className="text-xs text-au-gold font-handwriting text-base">College Sign In</span>
          <h2 className="text-2xl font-bold text-white font-serif-title">Sign in with Google</h2>
          <p className="text-xs text-au-text-muted">Only official @anurag.edu.in accounts are permitted.</p>
        </div>

        {error && (
          <div className="bg-rose-950/40 border border-rose-500/30 text-rose-200 p-3 rounded-2xl text-xs font-medium">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs text-au-text-muted mb-1.5 font-medium">College Google Email</label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="student@anurag.edu.in"
              className="w-full bg-au-bg border border-au-border rounded-2xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-au-accent"
            />
          </div>

          <div>
            <label className="block text-xs text-au-text-muted mb-1.5 font-medium">One-Time Registration Stamp Code</label>
            <input
              type="text"
              value={inviteCode}
              onChange={(e) => setInviteCode(e.target.value)}
              placeholder="ANURAG2026"
              className="w-full bg-au-bg border border-au-border rounded-2xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-au-accent uppercase"
            />
            <p className="text-[11px] text-au-text-dim mt-1">Required for first-time account registration.</p>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-au-accent hover:bg-au-accent-hover disabled:bg-au-card-hover disabled:text-au-text-dim text-white py-3.5 rounded-2xl text-xs font-bold transition shadow-lg shadow-amber-950/30"
          >
            {loading ? 'Authenticating...' : 'Authenticate Account'}
          </button>
        </form>
      </div>
    </div>
  );
}
